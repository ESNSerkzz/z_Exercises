#pragma once
#include "raymath.h"

const int windowHeight = 1000;
const int windowWidth = 1700;

