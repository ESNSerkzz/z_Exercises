#include "GameSpaceData.h"

void GameDataInfo::Draw()
{
}

void GameDataInfo::Update(float delta)
{
}
