#pragma once

static const int screenWidth = 896;
static const int screenHeight = 1152;

static const float palletSize = 4.0f;
static const float powerPalletSize = 10.0f;
static const float ghostSize = 15.0f;