#pragma once


static const int screenWidth = 2000;
static const int screenHeight = 1500;

static const float playerSpeed = 50.0f;
static const float torque = 10.0f;